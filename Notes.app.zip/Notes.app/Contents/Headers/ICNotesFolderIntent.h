//
// ICNotesFolderIntent.h
//
// This file was automatically generated and should not be edited.
//

#if __has_include(<Intents/Intents.h>)

#import <Intents/Intents.h>
#import "ICIntentNotesFolder.h"

NS_ASSUME_NONNULL_BEGIN

API_AVAILABLE(ios(12.0), macos(10.16), watchos(5.0))
@interface ICNotesFolderIntent : INIntent

@property (readwrite, copy, nullable, nonatomic) ICIntentNotesFolder *folder;

@end

@class ICNotesFolderIntentResponse;

/*!
 @abstract Protocol to declare support for handling a ICNotesFolderIntent. By implementing this protocol, a class can provide logic for resolving, confirming and handling the intent.
 @discussion The minimum requirement for an implementing class is that it should be able to handle the intent. The confirmation method is optional. The handling method is always called last, after confirming the intent.
 */
API_AVAILABLE(ios(12.0), macos(10.16), watchos(5.0))
@protocol ICNotesFolderIntentHandling <NSObject>

@required

/*!
@abstract Resolution methods - Determine if this intent is ready for the next step (confirmation)
@discussion Called to make sure the app extension is capable of handling this intent in its current form. This method is for validating if the intent needs any further fleshing out.

@param  intent The input intent
@param  completion The response block contains an INIntentResolutionResult for the parameter being resolved

@see INIntentResolutionResult
*/
- (void)resolveFolderForNotesFolder:(ICNotesFolderIntent *)intent withCompletion:(void (^)(ICIntentNotesFolderResolutionResult *resolutionResult))completion NS_SWIFT_NAME(resolveFolder(for:with:)) API_AVAILABLE(ios(13.0), macos(10.16), watchos(6.0));

/*!
 @abstract Dynamic options methods - provide options for the parameter at runtime
 @discussion Called to query dynamic options for the parameter and this intent in its current form.

 @param  intent The input intent
 @param  searchTerm The search term
 @param  completion The response block contains options for the parameter
 */
- (void)provideFolderOptionsCollectionForNotesFolder:(ICNotesFolderIntent *)intent searchTerm:(nullable NSString *)searchTerm withCompletion:(void (^)(INObjectCollection<ICIntentNotesFolder *> * _Nullable folderOptionsCollection, NSError * _Nullable error))completion NS_SWIFT_NAME(provideFolderOptionsCollection(for:searchTerm:with:)) API_AVAILABLE(ios(14.0), macos(10.16), watchos(7.0));

@optional

/*!
 @abstract Confirmation method - Validate that this intent is ready for the next step (i.e. handling)
 @discussion Called prior to asking the app to handle the intent. The app should return a response object that contains additional information about the intent, which may be relevant for the system to show the user prior to handling. If unimplemented, the system will assume the intent is valid, and will assume there is no additional information relevant to this intent.

 @param  intent The input intent
 @param  completion The response block contains a ICNotesFolderIntentResponse containing additional details about the intent that may be relevant for the system to show the user prior to handling.

 @see ICNotesFolderIntentResponse
 */
- (void)confirmNotesFolder:(ICNotesFolderIntent *)intent completion:(void (^)(ICNotesFolderIntentResponse *response))completion NS_SWIFT_NAME(confirm(intent:completion:));

/*!
 @abstract Handling method - Execute the task represented by the ICNotesFolderIntent that's passed in
 @discussion Called to actually execute the intent. The app must return a response for this intent.

 @param  intent The input intent
 @param  completion The response handling block takes a ICNotesFolderIntentResponse containing the details of the result of having executed the intent

 @see  ICNotesFolderIntentResponse
 */
- (void)handleNotesFolder:(ICNotesFolderIntent *)intent completion:(void (^)(ICNotesFolderIntentResponse *response))completion NS_SWIFT_NAME(handle(intent:completion:));

/*!
 @abstract Default values for parameters with dynamic options
 @discussion Called to query the parameter default value.
 */
- (nullable ICIntentNotesFolder *)defaultFolderForNotesFolder:(ICNotesFolderIntent *)intent NS_SWIFT_NAME(defaultFolder(for:)) API_AVAILABLE(ios(14.0), macos(10.16), watchos(7.0));

/*!
 @abstract Deprecated dynamic options methods.
 */
- (void)provideFolderOptionsForNotesFolder:(ICNotesFolderIntent *)intent withCompletion:(void (^)(NSArray<ICIntentNotesFolder *> * _Nullable folderOptions, NSError * _Nullable error))completion NS_SWIFT_NAME(provideFolderOptions(for:with:)) API_DEPRECATED("", ios(13.0, 14.0), watchos(6.0, 7.0));

@end

/*!
 @abstract Constants indicating the state of the response.
 */
typedef NS_ENUM(NSInteger, ICNotesFolderIntentResponseCode) {
    ICNotesFolderIntentResponseCodeUnspecified = 0,
    ICNotesFolderIntentResponseCodeReady,
    ICNotesFolderIntentResponseCodeContinueInApp,
    ICNotesFolderIntentResponseCodeInProgress,
    ICNotesFolderIntentResponseCodeSuccess,
    ICNotesFolderIntentResponseCodeFailure,
    ICNotesFolderIntentResponseCodeFailureRequiringAppLaunch
} API_AVAILABLE(ios(12.0), macos(10.16), watchos(5.0));

API_AVAILABLE(ios(12.0), macos(10.16), watchos(5.0))
@interface ICNotesFolderIntentResponse : INIntentResponse

- (instancetype)init NS_UNAVAILABLE;

/*!
 @abstract Initializes the response object with the specified code and user activity object.
 @discussion The app extension has the option of capturing its private state as an NSUserActivity and returning it as the 'currentActivity'. If the app is launched, an NSUserActivity will be passed in with the private state. The NSUserActivity may also be used to query the app's UI extension (if provided) for a view controller representing the current intent handling state. In the case of app launch, the NSUserActivity will have its activityType set to the name of the intent. This intent object will also be available in the NSUserActivity.interaction property.

 @param  code The response code indicating your success or failure in confirming or handling the intent.
 @param  userActivity The user activity object to use when launching your app. Provide an object if you want to add information that is specific to your app. If you specify nil, the system automatically creates a user activity object for you, sets its type to the class name of the intent being handled, and fills it with an INInteraction object containing the intent and your response.
 */
- (instancetype)initWithCode:(ICNotesFolderIntentResponseCode)code userActivity:(nullable NSUserActivity *)userActivity NS_DESIGNATED_INITIALIZER;

@property (readwrite, copy, nullable, nonatomic) ICIntentNotesFolder *folder;

/*!
 @abstract The response code indicating your success or failure in confirming or handling the intent.
 */
@property (readonly, NS_NONATOMIC_IOSONLY) ICNotesFolderIntentResponseCode code;

@end

NS_ASSUME_NONNULL_END

#endif
