//
// ICIntentNote.h
//
// This file was automatically generated and should not be edited.
//

#if __has_include(<Intents/Intents.h>)

#import <Intents/Intents.h>

NS_ASSUME_NONNULL_BEGIN

API_AVAILABLE(ios(12.0), macos(10.16), watchos(5.0))
@interface ICIntentNote : INObject

@end

API_AVAILABLE(ios(13.0), macos(10.16), watchos(6.0))
@interface ICIntentNoteResolutionResult : INObjectResolutionResult

// This resolution result is for when the app extension wants to tell Siri to proceed, with a given ICIntentNote. The resolvedValue can be different than the original ICIntentNote. This allows app extensions to apply business logic constraints.
// Use +notRequired to continue with a 'nil' value.
+ (instancetype)successWithResolvedIntentNote:(ICIntentNote *)resolvedObject NS_SWIFT_NAME(success(with:));

// This resolution result is to ask Siri to disambiguate between the provided ICIntentNote.
+ (instancetype)disambiguationWithIntentNotesToDisambiguate:(NSArray<ICIntentNote *> *)objectsToDisambiguate NS_SWIFT_NAME(disambiguation(with:));

// This resolution result is to ask Siri to confirm if this is the value with which the user wants to continue.
+ (instancetype)confirmationRequiredWithIntentNoteToConfirm:(ICIntentNote *)objectToConfirm NS_SWIFT_NAME(confirmationRequired(with:));

+ (instancetype)successWithResolvedObject:(__kindof INObject *)resolvedObject NS_UNAVAILABLE;
+ (instancetype)disambiguationWithObjectsToDisambiguate:(NSArray<__kindof INObject *> *)objectsToDisambiguate NS_UNAVAILABLE;
+ (instancetype)confirmationRequiredWithObjectToConfirm:(nullable __kindof INObject *)objectToConfirm NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END

#endif
